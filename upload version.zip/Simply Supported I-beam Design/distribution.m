function [mu,sigma,type]=distribution
mu=[1;1;1;1]';
type=1*[1;1;1;1];
sigma=[0.005;0.005;0.005;0.005]';